# SEA-CLOUD Android app wrapper

This Android Studio project packages the SEA-CLOUD web dashboard in a native Android WebView shell.

## Build APK

Requirements: Android Studio with Android SDK Platform 35 and JDK 17 or newer.

1. Open this folder in Android Studio.
2. Wait for Gradle sync.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio writes the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
5. Install that APK on the Realme P4x. On first launch, enter the HTTPS address where the SEA-CLOUD backend is deployed.

The app intentionally requires HTTPS for the server address. A server running only at `localhost` on another computer is not reachable from the phone.

## Notes

This is an Android client for the SEA-CLOUD web panel. It does not contain an Android emulator or cloud compute. The server must be deployed separately; actual virtual Android devices require a host/provider that supports Android virtualization.
