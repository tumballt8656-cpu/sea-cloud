package com.seacloud.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var address: EditText
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("sea_cloud", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showConnectScreen(prefs.getString("server_url", "") ?: "")
    }

    private fun showConnectScreen(savedUrl: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(28))
            setBackgroundColor(Color.rgb(11, 18, 32))
        }
        val title = TextView(this).apply {
            text = "SEA-CLOUD"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Hubungkan ke server cloud phone milikmu"
            textSize = 14f
            setTextColor(Color.rgb(157, 176, 199))
            setPadding(0, dp(8), 0, dp(24))
        }
        address = EditText(this).apply {
            hint = "https://alamat-server-kamu"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setText(savedUrl)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.rgb(25, 39, 58), dp(12))
        }
        val connect = Button(this).apply {
            text = "Hubungkan"
            isAllCaps = false
            setTextColor(Color.rgb(5, 34, 28))
            setBackgroundColor(Color.rgb(49, 198, 166))
            setOnClickListener { connectToServer() }
        }
        val note = TextView(this).apply {
            text = "Masukkan alamat HTTPS dashboard SEA-CLOUD yang sudah dipasang di server."
            textSize = 12f
            setTextColor(Color.rgb(130, 151, 176))
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(address, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))
        root.addView(connect, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(14) })
        root.addView(note)
        setContentView(root)
        address.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { connectToServer(); true } else false
        }
    }

    private fun connectToServer() {
        val raw = address.text.toString().trim().trimEnd('/')
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        if (uri == null || uri.scheme != "https" || uri.host.isNullOrBlank()) {
            Toast.makeText(this, "Gunakan alamat server HTTPS yang valid", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().putString("server_url", raw).apply()
        showWebView(raw)
    }

    private fun showWebView(url: String) {
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val target = request.url
                    if (target.scheme == "https" && target.host == Uri.parse(url).host) return false
                    startActivity(Intent(Intent.ACTION_VIEW, target))
                    return true
                }
            }
            loadUrl(url)
        }
        setContentView(webView)
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else showConnectScreen(prefs.getString("server_url", "") ?: "")
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
